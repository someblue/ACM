#include <iostream>
#include <cstdio>
#include <cstring>
#include <algorithm>
#define N 50010

using namespace std;

int bv[N],temp[N];

//void text()
//{
//    int sum=0;
//    int i,t=0;
//    for(i=1000000;t<50000;t++,i--) sum+=i;
//    printf("%d",sum);
//}

long long solve(int l,int r)
{
    int i,j,len;
    long long sum;
    len=r-l+1;
    for(i=l,j=0;i<=r;i++,j++)
    {
        temp[j]=bv[i];
    }
    sort(temp,temp+len);
    sum=temp[0];
    for(i=1;i<len;i++)
        if(temp[i]!=temp[i-1])
            sum+=temp[i];
    return sum;
}

int main()
{
    //text();
    freopen("in","r",stdin);
    int t,n,m,l,r,i;
    scanf("%d",&t);
    while(t--)
    {
        scanf("%d",&n);
        for(i=1;i<=n;i++)
            scanf("%d",&bv[i]);
        scanf("%d",&m);
        while(m--)
        {
            scanf("%d%d",&l,&r);
            printf("%lld\n",solve(l,r));
        }
    }
    return 0;
}
