#include <iostream>
#include <cstdio>
#include <cstring>
#include <algorithm>
#define N 50010
#define SN 15

using namespace std;

struct _vote{
    int time;
    long long pn;//phone number
    int singer;
    friend bool operator < (_vote a,_vote b)
    {
        return a.pn<b.pn||(a.pn==b.pn&&a.time<b.time);
    }
};

_vote v[N];
int voteres[SN];

void print(int n)
{
    int i;
    printf("time\tphone\tsinger\n");
    for(i=0;i<n;i++)
        printf("%d\t%lld\t%d\n",v[i].time,v[i].pn,v[i].singer);
}

void cntvote(int n)
{
    memset(voteres,0,sizeof(voteres));
    int i;
    voteres[v[0].singer]++;
    for(i=1;i<n;i++)
    {
        if(v[i].pn==v[i-1].pn&&v[i].time<v[i-1].time+60)
            continue;
        voteres[v[i].singer]++;
    }
}

void printvote(int n)
{
    int i,j;
    printf("The result is :\n");
    for(i=1;i<=n;i++)
    {
        printf("%02d : ",i);
        for(j=0;j<voteres[i];j++)
            printf("*");
        printf("\n");
    }
}

int main()
{
    freopen("in","r",stdin);
    char buf[50],tc;
    int n,hour,min,sec,ptr;
    while(scanf("%d",&n)!=EOF)
    {
        gets(buf);
        ptr=0;
        while(gets(buf),strcmp(buf,"#end")!=0)
        {
            sscanf(buf,"%d%c%d%c%d%lld%d",&hour,&tc,&min,&tc,&sec,&v[ptr].pn,&v[ptr].singer);
            v[ptr++].time=hour*3600+min*60+sec;
        }
        //print(ptr);
        sort(v,v+ptr);
        //print(ptr);
        cntvote(ptr);
        printvote(n);
    }
    return 0;
}
