#include <iostream>
#include <cstdio>
#include <cstring>
#define N 100010

using namespace std;

long long num[N];

long long gcd(long long  a,long long  b)
{
    return b==0?a:gcd(b,a%b);
}

long long llabs(long long a)
{
    return a>=0?a:0-a;
}

int main()
{
    long long sum,n,zuhe,gcdnum;
    int i,j;
    scanf("%d",&n);
    for(i=0;i<n;i++)
    {
        scanf("%lld",&num[i]);
    }
    sum=0;zuhe=0;
    for(i=0;i<n;i++) sum+=num[i];
    for(i=0;i<n;i++)
        for(j=i;j<n;j++)
        {
            zuhe+=llabs(num[i]-num[j]);
        }
    gcdnum=gcd(sum+zuhe*2,n);
    printf("%lld %lld\n",(sum+zuhe*2)/gcdnum,n/gcdnum);
    return 0;
}
