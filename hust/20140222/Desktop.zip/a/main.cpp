#include <iostream>
#include <cstdlib>
#include <cstdio>
#include <cstring>
#define N 1010
using namespace std;

int dp[N][N],w[N],v[N];//weight value

int solve(int n,int c)
{
    int i,j;
    for(i=1;i<=n;i++)
    {
        for(j=0;j<=c;j++)
        {
            dp[i][j]=(i==1?0:dp[i-1][j]);
            if(j>=v[i])
            {
                dp[i][j]=max(dp[i-1][j-v[i]]+w[i],dp[i][j]);
            }
        }
    }
    return dp[n][c];
}

int main()
{
    freopen("in","r",stdin);
    int t,n,c,i;
    scanf("%d",&t);
    while(t--)
    {
        scanf("%d%d",&n,&c);
        for(i=1;i<=n;i++) scanf("%d",&w[i]);
        for(i=1;i<=n;i++) scanf("%d",&v[i]);
        printf("%d\n",solve(n,c));
    }
    return 0;
}
