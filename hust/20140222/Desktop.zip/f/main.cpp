#include <iostream>
#include <cstdio>
#include <cstring>
#define N 210

using namespace std;

int num[2*N],sum[2*N];

void add(int n,int m)
{
    int p1,p2;
    for(p1=0,p2=n;p1<m-1;p1++,p2++)
        num[p2]=num[p1];
}

int solve(int n,int m)
{
    add(n,m);
    int len=n+m-1,i,maxsum;
    sum[m-1]=0;
    for(i=0;i<m;i++) sum[m-1]+=num[i];
    maxsum=sum[m-1];
    for(i=m;i<len;i++)
    {
        sum[i]=sum[i-1]+num[i]-num[i-m];
        if(maxsum<sum[i]) maxsum=sum[i];
    }
    return maxsum;
}

int main()
{
    freopen("Untitled2","r",stdin);
    int t,n,m,i;
    scanf("%d",&t);
//    printf("%d ",t);
    while(t--)
    {
        scanf("%d%d",&n,&m);
//        printf("%d %d\n",n,m);
        for(i=0;i<n;i++)
            scanf("%d",&num[i]);
//        for(i=0;i<n;i++)
//            printf("%d ",num[i]);
        printf("%d\n",solve(n,m));
    }
    return 0;
}
