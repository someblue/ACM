import java.io.*;
import java.util.*;
import java.math.*;
public class helloworld {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Hello World!");
		int n;
		Scanner cin = new Scanner(System.in);
		n = cin.nextInt();
		System.out.println(n);
		BigInteger b;
		b=BigInteger.ONE;
		b=b.add(BigInteger.ONE);
		System.out.println(b);
	}

}
